//Ryan McGuiness
#include <iostream>
#include <vector>
#include <string>
unsigned int RSHash(const std::string& str) {
    unsigned int b = 378551;
    unsigned int a = 63689;
    unsigned int hash = 0;
	for(std::size_t i = 0; i < str.length(); i++) {
		hash = hash * a + str[i]; 
		a =a*b;
	}
   return (hash & 0x7FFFFFFF);
}
unsigned int hash(unsigned int prehash){
	return prehash % size;
}
double hash_set(double y){
	std::vector<LinkedList*> table;
	unsigned int size;
	static unsigned int hash_str(string str);
	static unsigned int hash(unsigned int prehash);
}
bool contains(unsigned int key){
	bucketList = hashTable[Hash(key)];
	itemNode = ListSearch(bucketList, key);
   if (itemNode != node){
      return itemNode->data;
   }else{
      return false;
   }
}
bool insert(unsigned int key){
	if (HashSearch(hashTable, item->key) == null) {
      bucketList = hashTable[Hash(item->key)];
      node = Allocate new linked list node;
      node->next = null;
      node->data = item;
      ListAppend(bucketList, node);
	  }
   return; true;
}
bool remove(unsigned int key){
	bucketList = hashTable[Hash(item->key)];
	itemNode = ListSearch(bucketList, item->key);
   if (itemNode is not null) {
      ListRemove(bucketList, itemNode);
   } 
   return true;
}