#ifndef LinkedList_h
#define LinkedList_h

class ListNode {

  public:
    ListNode();
    ListNode(int value);
    ~ListNode();

    int value;
    int key;

    ListNode* next;
    ListNode* previous;
    ListNode* current;

};

class LinkedList {

  public:
  	LinkedList();
  	~LinkedList();

    int size;
    int data;
    ListNode* head;
    ListNode* tail;

  	bool insert_tail(unsigned int data);
  	bool insert_head(unsigned int data);
  	bool insert_at_index(unsigned int index, unsigned int data);
  	bool remove_head();
  	bool remove_tail();
  	bool remove_at_index(unsigned int index);
    unsigned int find(unsigned int data);
    unsigned int length();

};

#endif
