#ifndef HashSet_h
#define HashSet_h

#include "LinkedList.h"
#include <vector>

class HashSet
{
public:
    HashSet(int size);
    HashSet();
    ~HashSet();

     std::vector<LinkedList *> table; 
    unsigned int size;               

    bool contains(unsigned int key);
    bool insert(unsigned int key);   
    bool remove(unsigned int key);   
    
    

};

#endif
