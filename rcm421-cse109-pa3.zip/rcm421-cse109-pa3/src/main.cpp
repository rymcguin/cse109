//Ryan McGuiness
#include <iostream>
#include <vector>
#include <string>
#include <linked_list.cpp>

using namespace std;
//Avg insertion time
//Avg find time
int main(int argc, char const *argv[]){
	LinkedList* list = new LinkedList();
	Node *head = NULL;
	Node *last = NULL;
	File myfile = new File;
	myfile.open ("urls.txt");
	bool fileAdded = false;
	std::clock_t start;
    double duration;
    start = std::clock();
    /* Your algorithm here */
	if (myfile.is_open()){
    	while ( getline (myfile,line) ){
      	fileAdded = list->insert_head(line);
    	}
    	myfile.close();
  	}else{
	  	cout << "Unable to open file"; 
  	}
    duration = ( std::clock() - start ) / (double) CLOCKS_PER_SEC;
    std::cout<<"printf: "<< duration <<'\n';
	
	

  return 0;

} 

}