//Ryan McGuiness
#include <cstdlib>
#include <cstring>
#include <chrono>
#include <numeric>
#include <fstream>
#include <iostream>
#include <vector>
#include <string>
#include "../include/linked_list.h"
#include "../include/hash_set.h"

using namespace std;
void testHash(HashSet* set, int numValues, int* urls);
void testLink(LinkedList* list, int numValues, int* urls);
void makeLink(LinkedList *list, int *urls, unsigned int numUrls);
void makeHash(HashSet *set, int *urls, unsigned int numUrls);

void testHash(HashSet* set, int numValues, int* urls){
	std::chrono::duration<double> duration;
	auto start = std::chrono::system_clock::now();

	makeHash(set, urls, numValues);

	duration = std::chrono::system_clock::now() - start;
    cout << "Time to Insert Hash: " << duration.count() * 1000 << "ms" << endl;

	start = std::chrono::system_clock::now();

	for (int i = 0; i < numValues; i++){
		if (set->contains(urls[i])){
		}
	}
	duration = std::chrono::system_clock::now() - start;
  cout << "Time to find Hash: " << duration.count() * 1000 << "ms" << endl;
}
void testLink(LinkedList* list, int numValues, int* urls){
	auto start = chrono::system_clock::now();
	std::chrono::duration<double> duration;

	makeLink(list, urls, numValues);
	
	duration = std::chrono::system_clock::now() - start;
    cout << "Time to Insert in Link: " << duration.count() * 1000 << "ms" << endl;
	
	start = std::chrono::system_clock::now();
	
	for (int i = 0; i < numValues; i++){
		int index = list->find(urls[i]);
	}
	
	duration = std::chrono::system_clock::now() - start;
    cout << "Time to find in Link: " << duration.count() * 1000 << "ms" << endl;
}
void makeLink(LinkedList *list, int *urls, unsigned int numUrls){
	for (unsigned int i = 0; i < numUrls; i++){
		list->insert_tail(urls[i]);
	}
}
void makeHash(HashSet *set, int *urls, unsigned int numUrls){
	for (unsigned int i = 0; i < numUrls; i++){
		set->insert(urls[i]);	
	}
}

int main(){
	LinkedList* list = NULL;
	HashSet* set = NULL;
	int numUrls = 1000000;
	int* urls= new int[numUrls];

	ifstream inFile;
	inFile.open("urls.txt");
	string url = "";
	int counter = 0;
	string nextLine;
	if(inFile.is_open()){
		while(inFile >> nextLine){
			urls[counter] = HashSet::hash_str(nextLine);
			counter++;
		}
	}else{
		cout<<"File not open"<<endl;
		exit(0);
	}

	for (int i = 1000; i <= 1000000; i *= 10){
		list = new LinkedList();
		testLink(list, i, urls);
		delete list;
	}
	cout<<endl<<endl;

	for (int i = 1000; i <= 1000000; i *= 10){
		for (int j = 1000; j <= 1000000; j *= 10){
			set = new HashSet(i);
			testHash(set, j, urls);
			delete set;
		}
		cout<<endl<<endl;
	}

}
